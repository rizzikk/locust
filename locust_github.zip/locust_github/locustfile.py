from faker import Faker
from locust import HttpUser, task, SequentialTaskSet, TaskSet, between
import random
import json
import os

fake = Faker('ru_RU')

# сотрудник магазина: добавлять данные в API может только персонал
ADMIN_LOGIN = 'locust_admin'
ADMIN_PASSWORD = 'Locust_12345'

CATEGORIES = ['Тормозная система', 'Двигатель', 'Подвеска', 'Электрика', 'Фильтры',
              'Трансмиссия', 'Система охлаждения', 'Освещение', 'Масла и жидкости']
PARTS = ['Тормозные колодки', 'Масляный фильтр', 'Свеча зажигания', 'Амортизатор',
         'Ремень ГРМ', 'Аккумулятор', 'Фара', 'Помпа', 'Радиатор', 'Стартер']
CARS = ['Lada Vesta', 'Lada Granta', 'Kia Rio', 'Hyundai Solaris', 'Toyota Camry',
        'Volkswagen Polo', 'Skoda Octavia', 'Renault Logan']

# номера категорий и брендов из базы (API не возвращает id в ответах)
with open(os.path.join(os.path.dirname(__file__), 'ids.json'), encoding='utf-8') as f:
    IDS = json.load(f)


def category_data():
    name = random.choice(CATEGORIES)
    return {
        'name': name,
        'description': f'Раздел «{name}». Ответственный менеджер: {fake.name()}',
    }


def autopart_data():
    name = random.choice(PARTS)
    car = random.choice(CARS)
    return {
        'name': f'{name} {car}',
        'article': fake.bothify(text='??-#####', letters='ABCDEFGHKMPTX'),
        'description': f'{name} для автомобиля {car}. Гарантия {random.choice([6, 12, 24])} мес.',
        'price': round(random.uniform(150, 45000), 2),
        'stock_quantity': fake.random_int(min=0, max=500),
        'is_available': fake.boolean(chance_of_getting_true=80),
        'category': random.choice(IDS['categories']),
        'brands': [random.choice(IDS['brands'])],
    }


class CatalogBrowsing(TaskSet):
    """Гость смотрит каталог: задачи выбираются СЛУЧАЙНО (TaskSet)."""

    @task(5)
    def autoparts_list(self):
        self.client.get('/api/autoparts/', params={'page': random.randint(1, 2)},
                        name='/api/autoparts/?page=[n]')

    @task(3)
    def autoparts_search(self):
        self.client.get('/api/autoparts/', params={'search': random.choice(PARTS).split()[0]},
                        name='/api/autoparts/?search=[part]')

    @task(2)
    def categories_list(self):
        self.client.get('/api/categories/')


class AdminScenario(SequentialTaskSet):
    """Сотрудник: задачи выполняются СТРОГО ПО ПОРЯДКУ (SequentialTaskSet).
    @task(5) здесь означает, что задача повторяется 5 раз подряд."""

    def on_start(self):
        # вход через страницу авторизации DRF с CSRF-токеном
        self.client.get('/api-auth/login/', name='/api-auth/login/ (form)')
        self.client.post('/api-auth/login/', data={
            'username': ADMIN_LOGIN,
            'password': ADMIN_PASSWORD,
            'csrfmiddlewaretoken': self.client.cookies.get('csrftoken'),
            'next': '/api/',
        })
        self.client.headers['X-CSRFToken'] = self.client.cookies.get('csrftoken')

    @task
    def add_category(self):
        self.category = category_data()
        self.client.post('/api/categories/', json=self.category)

    @task(5)
    def find_category(self):
        self.client.get('/api/categories/', params={'search': self.category['name']},
                        name='/api/categories/?search=[new]')

    @task
    def add_autopart(self):
        self.part = autopart_data()
        self.client.post('/api/autoparts/', json=self.part)

    @task(5)
    def find_autopart(self):
        self.client.get('/api/autoparts/', params={'search': self.part['article']},
                        name='/api/autoparts/?search=[article]')


class GuestUser(HttpUser):
    weight = 3
    wait_time = between(1, 3)
    tasks = [CatalogBrowsing]


class AdminUser(HttpUser):
    weight = 1
    wait_time = between(1, 3)
    tasks = [AdminScenario]
