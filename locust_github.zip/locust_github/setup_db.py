# Подготовка БД autostore_api к нагрузочному тесту:
# создаёт сотрудника locust_admin, добавляет стартовые данные, сохраняет id в ids.json
import os, sys, json
API_DIR = r'C:\Users\GRUT\Desktop\3 курс\autostore_api'
sys.path.insert(0, API_DIR)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'autostore_api.settings')
import django
django.setup()
from django.contrib.auth.models import User
from api.models import Category, Brand, AutoPart

u, _ = User.objects.get_or_create(username='locust_admin')
u.is_staff = True
u.set_password('Locust_12345')
u.save()

if Category.objects.count() == 0:
    for n in ['Тормозная система', 'Двигатель', 'Подвеска', 'Фильтры', 'Электрика']:
        Category.objects.create(name=n, description='Стартовая категория')
if Brand.objects.count() == 0:
    for n, c in [('Bosch', 'Германия'), ('Brembo', 'Италия'), ('NGK', 'Япония'), ('Лада', 'Россия')]:
        Brand.objects.create(name=n, country=c)
if AutoPart.objects.count() < 10:
    cats = list(Category.objects.all()); brs = list(Brand.objects.all())
    for i, n in enumerate(['Тормозные колодки', 'Масляный фильтр', 'Свеча зажигания', 'Амортизатор',
                           'Ремень ГРМ', 'Аккумулятор', 'Фара', 'Помпа', 'Радиатор', 'Стартер']):
        p = AutoPart.objects.create(name=n, article=f'AP-{10000+i}', price=500 + i * 750,
                                    stock_quantity=10 + i, category=cats[i % len(cats)])
        p.brands.add(brs[i % len(brs)])

ids = {'categories': list(Category.objects.values_list('id', flat=True)[:50]),
       'brands': list(Brand.objects.values_list('id', flat=True)[:50])}
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ids.json'), 'w', encoding='utf-8') as f:
    json.dump(ids, f)
print('OK', 'категорий:', Category.objects.count(), 'брендов:', Brand.objects.count(),
      'товаров:', AutoPart.objects.count())
